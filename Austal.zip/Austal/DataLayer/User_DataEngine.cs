﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
namespace DataLayer
{
    public class User_DataEngine
    {
        public static  User GetUsers(int UserID)
        {
            
            User returnUser = new User();

            using (var db = new Austal_DBEntities())
            {

                List<User> Users = db.Users.Where(a => a.User_ID == UserID).Distinct().ToList();

                foreach (var User in Users)
                {

                    returnUser.first_name = User.first_name;
                    returnUser.last_name = User.last_name;
                    returnUser.job_Title = User.job_Title;
                    returnUser.birthday = User.birthday;
                    returnUser.hire_Date = User.hire_Date;
                    returnUser.activity = User.activity;

                }
            }
            return returnUser;
        }

        public static  User_Account GetAccount(int UserID)
        {

            User_Account returnAccount = new User_Account();

            using (var db = new Austal_DBEntities())
            {

                List<User_Account> User_Accounts = db.User_Account.Where(a => a.user_ID == UserID).Distinct().ToList();

                foreach (var User in User_Accounts)
                {

                    returnAccount.user_Name = User.user_Name;
                    returnAccount.bio = User.bio;
                    returnAccount.picture = User.picture;
                    returnAccount.email = User.email;
                    returnAccount.password = User.password;
                    returnAccount.user_ID = User.user_ID;
                   

                }
            }
            return returnAccount;
        }
        public static Department GetDepartment( int UserID)
        {
            Department returnDepartment = new Department();

            using (var db = new Austal_DBEntities())
            {

                List<Department> Department = db.Departments.Where(a => a.user_ID == UserID).Distinct().ToList();

                foreach (var dept in Department)
                {

                    returnDepartment.department_ID = dept.department_ID;
                    returnDepartment.dept_name = dept.dept_name;
                    returnDepartment.dept_location = dept.dept_location;
                    returnDepartment.user_ID = dept.user_ID;


                }
            }
            return returnDepartment;
        }

        public static Admin GetAdmin( int UserID)
        {
            Admin returnAdmin = new Admin();

            using (var db = new Austal_DBEntities())
            {

                List<Admin> Admin= db.Admins.Where(a => a.department_ID == UserID).Distinct().ToList();

                foreach (var adm in Admin)
                {

                    returnAdmin.admin_ID= adm.admin_ID;
                    returnAdmin.phone_Number = adm.phone_Number;
                    returnAdmin.department_ID = adm.department_ID;
                

                }
            }
            return returnAdmin;
        }
        public static List<Activity> GetActivity()
        {
            List<Activity> lst = null;
            using (Austal_DBEntities db = new Austal_DBEntities())
            {
                lst = (from u in db.Activities select u).ToList();
            }
            return lst;
        }

       

        public static  List<User> GetUsersBirthDate()
        {
            using (var db = new Austal_DBEntities())
            {

                List<User> users = db.Users.Distinct().ToList();
                return users;
            }
         
        }
    }
}
