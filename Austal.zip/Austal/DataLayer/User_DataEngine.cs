﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
namespace DataLayer
{
    public class User_DataEngine
    {
        public static List<User> GetUsers()
        {
            List<User> lst = null;
            using(Austal_DBEntities db = new Austal_DBEntities())
            {
                lst = (from u in db.Users select u).ToList();
            }
            return lst;
        }

        public static List<User_Account> GetAccount()
        {
            List<User_Account> lst = null;
            using (Austal_DBEntities db = new Austal_DBEntities())
            {
                lst = (from u in db.User_Account select u).ToList();
            }
            return lst;
        }
        public static List<Department> GetDepartment()
        {
            List<Department> lst = null;
            using (Austal_DBEntities db = new Austal_DBEntities())
            {
                lst = (from u in db.Departments select u).ToList();
            }
            return lst;
        }
    }
}
