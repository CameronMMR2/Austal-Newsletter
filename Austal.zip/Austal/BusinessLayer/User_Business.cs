﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer;
namespace BusinessLayer
{
    
    public class User_Business
    {

        User_DataEngine dataEngine = new User_DataEngine();
        public static User GetUsers(int UserID)
        {
            User returnUser = new User();
            returnUser = User_DataEngine.GetUsers(UserID);
            return returnUser;
        }
        public static User_Account GetAccount(int UserID)
        {
            User_Account returnAccount = new User_Account();
            returnAccount = User_DataEngine.GetAccount(UserID);
            return returnAccount;
        }
        public static Department GetDepartment(int UserID)
        {
            Department returnDept = new Department();
            returnDept = User_DataEngine.GetDepartment(UserID);
            return returnDept;
        }

        public static Admin GetAdmin(int UserID)
        {
            Admin returnAdm = new Admin();
            returnAdm = User_DataEngine.GetAdmin(UserID);
            return returnAdm;
        }

        public static List<Activity> GetActivity()
        {
            return User_DataEngine.GetActivity();
        }

        public static int  ValidUser(String uname, String lname)
        {
            using (var context = new Austal_DBEntities())
            {
                foreach (var User in context.User_Account.Where(a => a.user_Name == uname && a.password == lname))
                {
                    return 0;
                }
            }
            return 1;
        }

        public static int ID(string name)
        {
            Austal_DBEntities aus = new Austal_DBEntities();

            int austal = (from a in aus.User_Account where a.user_Name == name select a.user_ID).Single();

                return  austal;
            
            
        }
      // add to user table
        public bool AddUser(string FirstName, string LastName, string JobTitle, DateTime Birthday, DateTime HireDate, string Activity, string Username, string bio , string  email, string password)
        {
            User newUser = new User();
            User_Account newUserAccount = new User_Account();
            Department newDept = new Department();
            Admin newAdmin = new Admin();

            newUser.first_name = FirstName;
            newUser.last_name = LastName;
            newUser.job_Title = JobTitle;
            newUser.birthday = Birthday;
            newUser.hire_Date= HireDate;
            newUser.activity = Activity;

            newUserAccount.user_Name = Username;
            newUserAccount.bio = bio;
            newUserAccount.email = email;
            newUserAccount.password = password;

            //newUser.User.Add(newUserAccount);


         

            return User_DataEngine.AddUser(newUser);
        }
        
    }
}
