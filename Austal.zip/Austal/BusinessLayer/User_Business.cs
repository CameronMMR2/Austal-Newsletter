﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer;
namespace BusinessLayer
{
    public class User_Business
    {
        public static List<User> GetUsers()
        {
            return User_DataEngine.GetUsers();
        }
        public static List<User_Account> GetAccount()
        {
            return User_DataEngine.GetAccount();
        }
        public static List<Department> GetDepartment()
        {
            return User_DataEngine.GetDepartment();
        }
    }
}
