﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataLayer;
using BusinessLayer;
namespace Austal
{
    public partial class _interface : System.Web.UI.Page
    {
        Austal_DBEntities au = new Austal_DBEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
          /*  mainName.Text = (String)Session["name"]; */
            string name = (string)(Session["name"]);

            int Id = User_Business.ID(name);

            mainName.Text = User_Business.GetUsers(Id).first_name.ToString();

        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Remove("name");
            Session.RemoveAll();
            Response.Redirect("Login.aspx");
        }

        protected void btnProfile_Click(object sender, EventArgs e)
        {
            Response.Redirect("profile.aspx");
        }
    }
}