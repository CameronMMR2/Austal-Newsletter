﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataLayer;
using BusinessLayer;

namespace Austal
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<User> lstuser = User_Business.GetUsers();
            grduser.DataSource = lstuser;
            grduser.DataBind();

            List<User_Account> lstacc = User_Business.GetAccount();
            grdacc.DataSource = lstacc;
            grdacc.DataBind();

            List<Department> lstdept = User_Business.GetDepartment();
            grddep.DataSource = lstdept;
            grddep.DataBind();

        }
    }
}