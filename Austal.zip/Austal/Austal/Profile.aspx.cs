﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataLayer;
using BusinessLayer;

namespace Austal
{
    public partial class Profile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //load session state or username
            string name = (string)(Session["name"]);
            // get the user id from the session state
            int Id = User_Business.ID(name);

            Austal_DBEntities Au = new Austal_DBEntities();

            // from user table
            fname.Text = User_Business.GetUsers(Id).first_name.ToString();

            lname.Text = User_Business.GetUsers(Id).last_name.ToString();

            // from user Account table
            jtitile.Text = User_Business.GetUsers(Id).job_Title.ToString();

            bday.Text = User_Business.GetUsers(Id).birthday.ToString();

            hdate.Text = User_Business.GetUsers(Id).hire_Date.ToString();

            activity.Text = User_Business.GetUsers(Id).activity.ToString();

            // from user_Account table
            bio.Text = User_Business.GetAccount(Id).bio.ToString();

            email.Text = User_Business.GetAccount(Id).email.ToString();
      
       
            // dept
            Dept.Text = User_Business.GetDepartment(Id).dept_name.ToString();
            
           
           

       

        }

        protected void Goback_Click(object sender, EventArgs e)
        {
            Response.Redirect("main.aspx");
        }
    }
}