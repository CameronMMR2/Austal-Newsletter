﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataLayer;
using BusinessLayer;

namespace Austal
{
    public partial class admin : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {

            Austal_DBEntities Au = new Austal_DBEntities();
            string searchWord = txtSearch.Text;

            var results = Au.User_Account.Where(a => a.user_Name.Contains(searchWord));

            userGrid.DataSource = results.ToList();
            userGrid.DataBind();
        }

        protected void btnUpdatCal_Click(object sender, EventArgs e)
        {

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Austal_DBEntities Au = new Austal_DBEntities();

            //string searchWord = txtSearch.Text;

            //var results = Au.User_Account.Where(a => a.user_Name.Contains(searchWord));


            //var deleteOrderDetails =
            //from User in Au.Users
            //where User.User_ID = resu 
            //select details;

            //foreach (var detail in deleteOrderDetails)
            //{
            //    db.OrderDetails.DeleteOnSubmit(detail);
            //}

            //try
            //{
            //    db.SubmitChanges();
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e);
            //    // Provide for exceptions.
            //}

        }
    }
}