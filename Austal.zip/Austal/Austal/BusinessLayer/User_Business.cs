﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer;
namespace BusinessLayer
{
    
    public class User_Business
    {

        User_DataEngine dataEngine = new User_DataEngine();
        public static User GetUsers(int UserID)
        {
            User returnUser = new User();
            returnUser = User_DataEngine.GetUsers(UserID);
            return returnUser;
        }
        public static User_Account GetAccount(int UserID)
        {
            User_Account returnAccount = new User_Account();
            returnAccount = User_DataEngine.GetAccount(UserID);
            return returnAccount;
        }
       
        public static Admin GetAdmin(int UserID)
        {
            Admin returnAdm = new Admin();
            returnAdm = User_DataEngine.GetAdmin(UserID);
            return returnAdm;
        }
       
        public static int  ValidUser(String uname, String lname)
        {
            using (var context = new Austal_DBEntities())
            {
                foreach (var User in context.User_Account.Where(a => a.user_Name == uname && a.password == lname))
                {
                    return 0;
                }
            }
            return 1;
        }

        public static int ID(string name)
        {
            Austal_DBEntities aus = new Austal_DBEntities();

            int austal = (from a in aus.User_Account where a.user_Name == name select a.user_ID).Single();

                return  austal;
            
            
        }
      // add to user table
       
  
        public static  List<String> GetBirthdate()
        {
            List<String > Bday = new List<String>();

            List<User> Users = User_DataEngine.GetUsersBirthDate();

            foreach (var User in Users )
            {
                Bday.Add(User.first_name.ToString() +" " + User.birthday);
               // Bday.Add(User.birthday.ToString());    
            }
            return Bday;

        }
        // add user to table
        public static bool AddUser(string fname, string lname, string jobtitle, DateTime bday, DateTime hday, string Actvity, string uname, string bio, byte[] picture, string email, string password, string dept)
        {

            User newUser = new User();
            User_Account newUserAccount = new User_Account();



            newUser.first_name = fname;
            newUser.last_name = lname;
            newUser.job_Title = jobtitle;
            newUser.birthday = bday;
            newUser.hire_Date = hday;
            newUser.activity = Actvity;

            newUserAccount.user_Name = uname;
            newUserAccount.bio = bio;
            newUserAccount.picture = picture;
            newUserAccount.email = email;
            newUserAccount.password = password;
            newUserAccount.department = dept;
            



            newUser.User_Account.Add(newUserAccount);


            return User_DataEngine.AddUser(newUser);

        }

        //update user table 
         
    }
}
