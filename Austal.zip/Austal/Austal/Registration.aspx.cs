﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataLayer;
using BusinessLayer;


namespace Austal
{
    public partial class Registration1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        

        protected void Submit_Click(object sender, EventArgs e)
        {

            
              String fname = FirstName.Text;
              String lname = LastName.Text;
              String jtitle = JobTitle.Text;
              DateTime bday = Convert.ToDateTime(BirthDate.Text);
              DateTime hday = default(DateTime);
              string act = "";

                string uname = UserName.Text;
                string bio = "";
                byte[] image = new byte[64];
                string email = "";
                string password = PassWord.Text;


              User_Business.AddUser( fname, lname, jtitle, bday, hday,act,uname,bio,image,email,password);

              
            /*
              String uname = UsernameTextBox.Text;
              String bio = BioTextBox.Text;
              String email = EmailTextBox.Text;
              String password = PassWordTextBox.Text;

              String deptName = "";
              String deptLocation = "";
              String phoneNumber = "";


              // User_Business.AddUser(fname, lname, jtitle, bday, hday, act, uname, bio, email, password);
              // User_Business.AddUser_Account(uname,bio,email,password);
              */
            Response.Redirect("Login.aspx");
        }
    }
}