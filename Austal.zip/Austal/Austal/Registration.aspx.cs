﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataLayer;
using BusinessLayer;


namespace Austal
{
    public partial class Registration1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        

        protected void Submit_Click(object sender, EventArgs e)
        {
            /*
              FirstNameTextBox.Text =
              String fname = FirstNameTextBox.Text;
              String lname = LastNameTextBox.Text;
              String jtitle = JobTitleTextBox.Text;
              DateTime bday = Convert.ToDateTime(BdayTextBox.Text);
              DateTime hday = Convert.ToDateTime(HiredateTextBox.Text);
              String act = ActivityTextBox.Text;

              String uname = UsernameTextBox.Text;
              String bio = BioTextBox.Text;
              String email = EmailTextBox.Text;
              String password = PassWordTextBox.Text;

              String deptName = "";
              String deptLocation = "";
              String phoneNumber = "";


              // User_Business.AddUser(fname, lname, jtitle, bday, hday, act, uname, bio, email, password);
              // User_Business.AddUser_Account(uname,bio,email,password);
              */
            Response.Redirect("Login.aspx");
        }
    }
}