﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataLayer;
using BusinessLayer;

namespace Austal
{
    public partial class Login : System.Web.UI.Page
    {
        private Austal_DBEntities Au = new Austal_DBEntities();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
        
            string uname = UserNameTextBox.Text;
            string pass = PassWordTextBox.Text;
            

            if (User_Business.ValidUser(uname, pass) == 0)
            {
                if (User_Business.ValidAdmin(uname, pass) == 0)
                {
                    Session["name"] = uname;
                    Response.Redirect("admin.aspx");
                }
                else
                {
                    Session["name"] = uname;
                    Response.Redirect("main.aspx");
                }
            }
            else
            {
                UserNameTextBox.Text = String.Empty;
                PassWordTextBox.Text = String.Empty;
            }

        }

       

        protected void NewUser_Click1(object sender, EventArgs e)
        {
            Response.Redirect("registration.aspx");
        }
    }
}