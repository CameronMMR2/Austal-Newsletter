﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataLayer;
using BusinessLayer;

namespace Austal
{
    public partial class Profile : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            //load session state or username
            string name = (string)(Session["name"]);
            // get the user id from the session state
            int Id = User_Business.ID(name);

            Austal_DBEntities Au = new Austal_DBEntities();

            // from user table
            fname.Text = User_Business.GetUsers(Id).first_name.ToString();

            lname.Text = User_Business.GetUsers(Id).last_name.ToString();

            // from user Account table
            jtitile.Text = User_Business.GetUsers(Id).job_Title.ToString();

            bday.Text = User_Business.GetUsers(Id).birthday.ToString();

            hdate.Text = User_Business.GetUsers(Id).hire_Date.ToString();

            activity.Text = User_Business.GetUsers(Id).activity.ToString();

            // from user_Account table
            bio.Text = User_Business.GetAccount(Id).bio.ToString();

            email.Text = User_Business.GetAccount(Id).email.ToString();

            Dept.Text = User_Business.GetAccount(Id).department.ToString();

          
        }



        protected void Goback_Click(object sender, EventArgs e)
        {
            Response.Redirect("main.aspx");
        }

        protected void Edit_Click(object sender, EventArgs e)
            {
                FirstName.Visible = true;
                FirstName.Text = fname.Text.ToString();

                LastName.Visible = true;
                LastName.Text = lname.Text.ToString();

                JobTitle.Visible = true;
                JobTitle.Text = jtitile.Text.ToString();

                Department.Visible = true;
                Department.Text = Dept.Text.ToString();

                ActivityEdit.Visible = true;
                ActivityEdit.Text = activity.Text.ToString();

                BioEdit.Visible = true;
                BioEdit.Text = bio.Text.ToString();

                EmailEdit.Visible = true;
                EmailEdit.Text = email.Text.ToString();

                fname.Visible = false;
                lname.Visible = false;
                jtitile.Visible = false;
                Dept.Visible = false;
                bio.Visible = false;
                activity.Visible = false;
                email.Visible = false;

            }
        protected void SubmitEdit_Click(object sender, EventArgs e)
            {
                string name = (string)(Session["name"]);
                // get the user id from the session state
                int? Id = User_Business.ID(name);
 
                 DataClasses1DataContext db = new DataClasses1DataContext();

                 var ua = from c in db.Users
                         where c.User_ID == Id
                        select c;
                 foreach( var a in ua)
                       {

                        a.first_name = FirstName.Text.ToString();
                        a.last_name = LastName.Text.ToString();
                        a.first_name = FirstName.Text.ToString();
                        a.job_Title = JobTitle.Text.ToString();
                        a.activity = ActivityEdit.Text.ToString();
                       }
                        var  uac = from c in db.User_Accounts
                              where c.user_ID == Id
                              select c;
                        foreach( var ac in uac)
                        {
                        ac.bio = BioEdit.Text.ToString();
                        ac.email = EmailEdit.Text.ToString();
                        ac.department = Department.Text.ToString();
                        }
                  
                        db.SubmitChanges();

                        

                            Response.Redirect(Request.RawUrl);
         
            
              }
    
            }
   }
