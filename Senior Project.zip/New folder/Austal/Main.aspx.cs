﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataLayer;
using BusinessLayer;
namespace Austal
{

    public partial class _interface : System.Web.UI.Page
    {

        Austal_DBEntities au = new Austal_DBEntities();
        string[,] holidays = new String[13, 32];
        string[] bdays = User_Business.GetBirthdate().ToArray();

        protected void Page_Load(object sender, EventArgs e)
        {

            /*  mainName.Text = (String)Session["name"]; */
            string name = (string)(Session["name"]);

            int Id = User_Business.ID(name);

            mainName.Text = User_Business.GetUsers(Id).first_name.ToString();
            // calender holidays
            //Calendar1.SelectedDate = Convert.ToDateTime(User_Business.GetBirthdate().ToString());
           

            holidays[1, 1] = "New Years Day"; 
            holidays[1, 17] = "Martin Luther King Day"; // Will have to be changed Yearly
            holidays[2, 14] = "Valentine's Day"; 
            holidays[2, 20] = "Presidents' Day";// Will have to be changed yearly 
            holidays[4, 16] = "Easter Sunday"; // Will have to be changed Yearly 
            holidays[5, 14] = "Mothers' Day"; // Will have to be changed Yearly 
            holidays[5, 22] = "National Meritime Day";
            holidays[5, 29] = "Memorial Day"; // Will have to be changed Yearly 
            holidays[6, 18] = "Fathers' Day"; // Will have to be changed Yearly 
            holidays[7, 4] = "Independence Day";
            holidays[9, 4] = "Labor Day"; // Will have to be changed Yearly 
            holidays[10, 9] = "Columbus Day"; // Will have to be changed Yearly 
            holidays[10, 31] = "Halloween"; 
            holidays[11, 11] = "Veterans Day"; 
            holidays[11, 24] = "Thanksgiving Day"; 
            holidays[12, 24] = "Christmas Eve Day"; 
            holidays[12, 25] = "Christmas Day";

           
             
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Remove("name");
            Session.RemoveAll();
            Response.Redirect("Login.aspx");
        }

        protected void btnProfile_Click(object sender, EventArgs e)
        {
            Response.Redirect("profile.aspx");
        }

       
        
        protected void Calender1_DayRender(object sender, DayRenderEventArgs e)
        {
            //render holidays to calender 
            string aHoliday;
            DateTime theDate = e.Day.Date;
            aHoliday = holidays[theDate.Month, theDate.Day];
            if (aHoliday != null)
            {
                Label aLabel = new Label();
                aLabel.Text = " <br>" + aHoliday;
                e.Cell.Controls.Add(aLabel);
                e.Cell.BackColor = System.Drawing.Color.Blue;
                e.Cell.BorderColor  = System.Drawing.Color.Black;
            }
          // Add birthdays to calender
           string[] bdays = User_Business.GetBirthdate().ToArray();

            foreach (string a in bdays)
            {
                DateTime d ;
                //Event.Text = a;
                var uname = a.Split(' ')[0];
                var dates = a.Substring(a.IndexOf(' '));

                d = Convert.ToDateTime(dates);
                
              
                
                if (d.Day == theDate.Day && d.Month == theDate.Month )
                {
                Label bLabel = new Label();
                bLabel.Text = "<br>"+"Today is " + uname + " Birthday";
                e.Cell.Controls.Add(bLabel);
                e.Cell.BackColor = System.Drawing.Color.Blue;
                } 
         
            }      
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
         // Event.Text= User_Business.GetBirthdate().ToString();
        }

        protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void Admin_Click(object sender, EventArgs e)
        {
            AdminPassword.Visible = true;
            Enter.Visible = true;
            Admin.Visible = false;       
        }

        protected void Enter_Click(object sender, EventArgs e)
        {
            if (AdminPassword.Text == "abc")
            {
                Response.Redirect("admin.aspx");
            }
            else
            {
                Admin.Visible = true;
                Enter.Visible = false;
                AdminPassword.Visible = false;
            }
        }

        protected void AdminPassword_TextChanged(object sender, EventArgs e)
        {

        }

      


       

    }
    
}