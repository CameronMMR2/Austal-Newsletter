﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataLayer;
using BusinessLayer;

namespace Austal
{
    public partial class admin : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
        

      

        protected void btnSearch_Click(object sender, EventArgs e)
        {

            Austal_DBEntities Au = new Austal_DBEntities();
            string searchWord = txtSearch.Text;


            var userdata = (from a in Au.Users
                            where a.first_name.Contains(searchWord)
                            join ab in Au.User_Account on a.User_ID equals ab.user_ID 
                            
                            select new { a.first_name,
                                         a.last_name,
                                         a.job_Title,
                                         a.birthday,
                                         a.hire_Date,
                                         a.activity,
                                         ab.user_Name,
                                         ab.password,
                                         ab.email,
                                         ab.department,
                                          ab.bio}).ToList();

           

            userGrid.DataSource = userdata;
            userGrid.EditIndex = -1;
            userGrid.DataBind();

            
            

          
        }

       
       
        protected void btnUpdatCal_Click(object sender, EventArgs e)
        {

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Austal_DBEntities Au = new Austal_DBEntities();

            //string searchWord = txtSearch.Text;

            //var results = Au.User_Account.Where(a => a.user_Name.Contains(searchWord));


            //var deleteOrderDetails =
            //from User in Au.Users
            //where User.User_ID = resu 
            //select details;

            //foreach (var detail in deleteOrderDetails)
            //{
            //    db.OrderDetails.DeleteOnSubmit(detail);
            //}

            //try
            //{
            //    db.SubmitChanges();
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e);
            //    // Provide for exceptions.
            //}

        }


        protected void MainPage_Click(object sender, EventArgs e)
        {
            Response.Redirect("main.aspx");
        }

      
       
    }
}