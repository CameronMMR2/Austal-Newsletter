﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataLayer;
using BusinessLayer;

namespace Austal
{
    public partial class admin1 : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {

            Austal_DBEntities Au = new Austal_DBEntities();
            string searchWord = txtSearch.Text;


            var userdata = (from a in Au.Users
                            where a.first_name.Contains(searchWord)
                            join ab in Au.User_Account on a.User_ID equals ab.user_ID

                            select new
                            {
                                a.User_ID,
                                a.first_name,
                                a.last_name,
                                a.job_Title,
                                a.birthday,
                                a.hire_Date,
                                a.activity,
                                ab.user_Name,
                                ab.password,
                                ab.email,
                                ab.department,
                                ab.bio
                            }).ToList();



            userGrid.DataSource = userdata;
            userGrid.EditIndex = -1;
            userGrid.DataBind();

            txtSearch.Visible = false;
            txtDelete.Visible = true;
            btnDelete.Visible = true;
            btnEdit.Visible = true;

        }



        protected void btnUpdatCal_Click(object sender, EventArgs e)
        {

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {

            DataClasses1DataContext db = new DataClasses1DataContext();
            User tc = new User();

            int userVal = int.Parse(txtDelete.Text);
            tc.User_ID = userVal;

            var removeUser = from c in db.Users
                             where (c.User_ID == tc.User_ID)
                             select c;

            var removeUserAccount = from c in db.User_Accounts
                                    where (c.user_ID == tc.User_ID)
                                    select c;


            db.Users.DeleteAllOnSubmit(removeUser);
            db.User_Accounts.DeleteAllOnSubmit(removeUserAccount);
            db.SubmitChanges();



        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            if (txtDelete == null)
            {
                Response.Redirect(Request.RawUrl);
            }
            else
            {
                DataClasses1DataContext db = new DataClasses1DataContext();
                User tc = new User();

                int userVal = int.Parse(txtDelete.Text);
                tc.User_ID = userVal;

                var editUser = from c in db.Users
                               where (c.User_ID == tc.User_ID)
                               select c;
                //show edit lables and textboxes
                Fname.Visible = true;
                lbfname.Visible = true;
                Lname.Visible = true;
                lblname.Visible = true;
                Jtitle.Visible = true;
                lbjtitle.Visible = true;
                Activity.Visible = true;
                lbact.Visible = true;
                Bday.Visible = true;
                lbbday.Visible = true;
                Hiredate.Visible = true;
                lbhday.Visible = true;
                foreach (var a in editUser)
                {

                    Fname.Text = a.first_name.ToString();
                    Lname.Text = a.last_name.ToString();
                    Jtitle.Text = a.job_Title.ToString();
                    Activity.Text = a.activity.ToString();
                    Bday.Text = a.birthday.ToString("mm/dd/yyyy");
                    Hiredate.Text = a.hire_Date.ToString();
                }
                // show boxes to edit sencond table

                Username.Visible = true;
                lbuname.Visible = true;
                Email.Visible = true;
                lbemail.Visible = true;
                Password.Visible = true;
                lbpword.Visible = true;
                Department.Visible = true;
                lbdept.Visible = true;
                Bio.Visible = true;
                lbbio.Visible = true;
                Submit.Visible = true;
                var editUserAccount = from c in db.User_Accounts
                                      where (c.user_ID == tc.User_ID)
                                      select c;


                foreach (var a in editUserAccount)
                {

                    Bio.Text = a.bio.ToString();
                    Username.Text = a.user_Name.ToString();
                    Email.Text = a.email.ToString();
                    Password.Text = a.password.ToString();
                    Department.Text = a.department.ToString();
                }
            }

        }



/*
        protected void MainPage_Click(object sender, EventArgs e)
        {
            Response.Redirect("main.aspx");
        }
*/
        protected void Submit_Click(object sender, EventArgs e)
        {
            DataClasses1DataContext db = new DataClasses1DataContext();
            User tc = new User();

            int userVal = int.Parse(txtDelete.Text);
            tc.User_ID = userVal;

            var editUser = from c in db.Users
                           where (c.User_ID == tc.User_ID)
                           select c;
            Fname.Visible = true;
            foreach (var a in editUser)
            {

                a.first_name = Fname.Text.ToString();
                a.last_name = Lname.Text.ToString();
                a.job_Title = Jtitle.Text.ToString();
                a.activity = Activity.Text.ToString();
                a.birthday = Convert.ToDateTime(Bday.Text);
                a.hire_Date = Convert.ToDateTime(Hiredate.Text);

            }

            var editUserAccount = from c in db.User_Accounts
                                  where (c.user_ID == tc.User_ID)
                                  select c;
            foreach (var a in editUserAccount)
            {

                a.user_Name = Username.Text.ToString();
                a.email = Email.Text.ToString();
                a.password = Password.Text.ToString();
                a.department = Department.Text.ToString();

            }

            db.SubmitChanges();

            Response.Redirect(Request.RawUrl);
        }

        protected void main_Click(object sender, EventArgs e)
        {
            Response.Redirect("main.aspx");
        }



    }
}