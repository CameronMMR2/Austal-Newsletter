﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataLayer;
using BusinessLayer;

namespace Austal
{
    public partial class admin : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
        

        protected void btnSearch_Click(object sender, EventArgs e)
        {

            Austal_DBEntities Au = new Austal_DBEntities();
            string searchWord = txtSearch.Text;


            var userdata = (from a in Au.Users
                            where a.first_name.Contains(searchWord)
                            join ab in Au.User_Account on a.User_ID equals ab.user_ID 
                            
                            select new { a.User_ID,
                                         a.first_name,
                                         a.last_name,
                                         a.job_Title,
                                         a.birthday,
                                         a.hire_Date,
                                         a.activity,
                                         ab.user_Name,
                                         ab.password,
                                         ab.email,
                                         ab.department,
                                          ab.bio}).ToList();

           

            userGrid.DataSource = userdata;
            userGrid.EditIndex = -1;
            userGrid.DataBind();

           
            
            

          
        }
        protected void userGrid_RowEditing(object sender ,GridViewEditEventArgs e)
        {
            userGrid.EditIndex = e.NewEditIndex;
            DataBind();
           
        }
        protected void userGrid_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Austal_DBEntities Au = new Austal_DBEntities();
            User ua = new User();

            var ud = (from a in Au.Users
                            join ab in Au.User_Account on a.User_ID equals ab.user_ID

                            select new
                            {

                                a.first_name,
                                a.last_name,
                                a.job_Title,
                                a.birthday,
                                a.hire_Date,
                                a.activity,
                                ab.user_Name,
                                ab.password,
                                ab.email,
                                ab.department,
                                ab.bio
                            }).ToList();
           
            
        }
        private void BindData()
        {
            userGrid.DataSource = Session["User"];
            userGrid.DataBind();
        }
       
       
        protected void btnUpdatCal_Click(object sender, EventArgs e)
        {

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
          
            DataClasses1DataContext db = new DataClasses1DataContext();
            User tc = new User();

            int userVal = int.Parse(txtDelete.Text);
            tc.User_ID = userVal;
  
           var removeUser = from c in db.Users
                            where (c.User_ID == tc.User_ID)
                            select c;

           var removeUserAccount = from c in db.User_Accounts
                                   where (c.user_ID == tc.User_ID)
                                   select c; 


           db.Users.DeleteAllOnSubmit(removeUser);
           db.User_Accounts.DeleteAllOnSubmit(removeUserAccount);
           db.SubmitChanges(); 

            

        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            

        }
          
           

        
        protected void MainPage_Click(object sender, EventArgs e)
        {
            Response.Redirect("main.aspx");
        }

        

      
       
    }
}